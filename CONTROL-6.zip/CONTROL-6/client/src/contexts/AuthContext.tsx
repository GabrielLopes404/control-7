import { createContext, useContext, ReactNode } from "react";
import { useAuth, useLogout } from "@/hooks/use-api";

interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  avatar?: string;
  theme?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  logout: () => void;
  refetch: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, refetch, isError } = useAuth();
  const logoutMutation = useLogout();

  const user = data?.user || null;
  const isAuthenticated = !!user && !isError;

  const logout = () => {
    logoutMutation.mutate();
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, isAuthenticated, logout, refetch }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuthContext must be used within an AuthProvider");
  }
  return context;
}
