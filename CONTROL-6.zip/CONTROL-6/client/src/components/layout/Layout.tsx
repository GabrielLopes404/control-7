import { Sidebar, MobileNav } from "./Sidebar";
import { Bell, Search, Command, Check, CheckCheck } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useNotifications } from "@/contexts/NotificationContext";
import { useAuthContext } from "@/contexts/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { notifications, unreadCount, markAsRead, markAllAsRead, isConnected } = useNotifications();
  const { user } = useAuthContext();

  const formatDate = (dateString: string | Date) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: ptBR });
    } catch {
      return "";
    }
  };

  const userInitials = user?.name?.split(" ").map(n => n[0]).join("").substring(0, 2).toUpperCase() || "U";

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen max-h-screen overflow-hidden">
        <header className="h-16 border-b border-border/50 glass-strong sticky top-0 z-20 flex items-center justify-between px-4 md:px-6 shrink-0">
          <div className="flex items-center gap-3 flex-1">
            <MobileNav />
            <div className="relative hidden md:flex items-center w-full max-w-md">
              <div className="absolute left-3 flex items-center gap-2 text-muted-foreground pointer-events-none">
                <Search className="w-4 h-4" />
              </div>
              <Input 
                placeholder="Buscar..." 
                className="pl-10 pr-16 h-10 bg-muted/30 border-border/50 hover:border-border focus:border-primary/50 focus:bg-muted/50 transition-all rounded-xl"
              />
              <div className="absolute right-2 hidden lg:flex items-center gap-1 text-muted-foreground text-xs bg-muted/50 px-2 py-1 rounded-md">
                <Command className="w-3 h-3" /> K
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-xl h-10 w-10">
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-primary rounded-full ring-2 ring-background pulse-glow"></span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 glass-strong border-border/50 rounded-xl p-0 overflow-hidden">
                <div className="p-4 border-b border-border/50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-heading font-bold text-sm uppercase tracking-wider">Notificações</span>
                    {isConnected && (
                      <span className="w-2 h-2 bg-emerald-500 rounded-full" title="Conectado em tempo real"></span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <div className="flex items-center gap-2">
                      <Badge className="bg-primary/20 text-primary border-0 text-xs">{unreadCount} novas</Badge>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-6 w-6 text-muted-foreground hover:text-primary"
                        onClick={(e) => {
                          e.preventDefault();
                          markAllAsRead();
                        }}
                        title="Marcar todas como lidas"
                      >
                        <CheckCheck className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="p-8 text-center text-muted-foreground">
                      <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Nenhuma notificação</p>
                    </div>
                  ) : (
                    notifications.slice(0, 10).map((notif) => (
                      <DropdownMenuItem 
                        key={notif.id} 
                        className={cn(
                          "flex flex-col items-start gap-1.5 p-4 cursor-pointer rounded-none border-b border-border/30 last:border-0 focus:bg-muted/50",
                          !notif.read ? "bg-primary/5" : ""
                        )}
                        onClick={() => markAsRead(notif.id)}
                      >
                        <div className="flex items-center justify-between w-full gap-2">
                          <div className="flex items-center gap-2">
                            <div className={cn(
                              "w-2 h-2 rounded-full shrink-0",
                              notif.type === "warning" ? "bg-yellow-500" :
                              notif.type === "error" ? "bg-red-500" :
                              notif.type === "success" ? "bg-emerald-500" : "bg-primary"
                            )} />
                            <span className="font-semibold text-sm">{notif.title}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            {!notif.read && (
                              <Check className="w-3 h-3 text-primary" />
                            )}
                            <span className="text-[10px] text-muted-foreground shrink-0">
                              {formatDate(notif.createdAt)}
                            </span>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 pl-4">{notif.message}</p>
                      </DropdownMenuItem>
                    ))
                  )}
                </div>
                {notifications.length > 0 && (
                  <div className="p-3 border-t border-border/50 bg-muted/20">
                    <Button variant="ghost" className="w-full h-9 text-xs font-medium text-primary hover:bg-primary/10 rounded-lg">
                      Ver todas as notificações
                    </Button>
                  </div>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <div className="hidden md:flex items-center gap-3 pl-3 border-l border-border/50">
              <div className="text-right">
                <p className="text-sm font-semibold leading-tight">{user?.name || "Usuário"}</p>
                <p className="text-[11px] text-muted-foreground">Administrador</p>
              </div>
              <Avatar className="h-9 w-9 border-2 border-primary/30 hover:border-primary transition-colors cursor-pointer">
                <AvatarFallback className="bg-gradient-to-br from-primary/20 to-purple-500/20 text-sm font-bold">{userInitials}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          <div className="p-4 md:p-6 lg:p-8 min-h-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
