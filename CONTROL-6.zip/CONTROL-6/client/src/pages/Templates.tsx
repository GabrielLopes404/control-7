import { useState } from "react";
import { useTemplates, useCreateTemplate, useUpdateTemplate, useDeleteTemplate } from "@/hooks/use-api";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Star, ArrowRight, Sparkles, Search, Copy, Plus, MoreHorizontal, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const categories = ["Todos", "Propostas", "Jurídico", "Design", "Relatórios", "Processos", "Comunicação"];

export default function Templates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "Propostas",
  });

  const { data: templates = [], isLoading } = useTemplates();
  const createMutation = useCreateTemplate();
  const updateMutation = useUpdateTemplate();
  const deleteMutation = useDeleteTemplate();

  const filteredTemplates = templates.filter(
    (template: any) =>
      (selectedCategory === "Todos" || template.category === selectedCategory) &&
      template.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setFormData({ title: "", content: "", category: "Propostas" });
    setEditingTemplate(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (template: any) => {
    setFormData({
      title: template.title,
      content: template.content || "",
      category: template.category || "Propostas",
    });
    setEditingTemplate(template);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingTemplate) {
        await updateMutation.mutateAsync({ id: editingTemplate.id, data: formData });
        toast.success("Template atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Template criado com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar template");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este template?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Template excluído com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir template");
    }
  };

  const handleUseTemplate = (template: any) => {
    navigator.clipboard.writeText(template.content || template.title);
    toast.success("Conteúdo copiado para a área de transferência!");
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4 sm:space-y-6"
    >
      <motion.div variants={item} className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Templates</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Documentos prontos para acelerar seu trabalho.</p>
        </div>
        <Button 
          onClick={openCreateDialog}
          className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl"
        >
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Criar Template
        </Button>
      </motion.div>

      <motion.div variants={item} className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <Copy className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{templates.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-amber-500/10 rounded-lg sm:rounded-xl text-amber-500">
              <Star className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Categorias</p>
              <p className="text-lg sm:text-xl font-bold font-heading">
                {new Set(templates.map((t: any) => t.category)).size}
              </p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Último Adicionado</p>
              <p className="text-lg sm:text-xl font-bold font-heading truncate">
                {templates[0]?.title || "Nenhum"}
              </p>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div variants={item} className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar templates..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="overflow-x-auto flex gap-1 sm:gap-1.5 px-2 sm:px-0 hide-scrollbar-mobile">
          {categories.slice(0, 5).map((cat) => (
            <Button 
              key={cat}
              variant={selectedCategory === cat ? "secondary" : "ghost"} 
              size="sm"
              onClick={() => setSelectedCategory(cat)}
              className={cn(
                "h-7 sm:h-8 px-2 sm:px-3 text-[10px] sm:text-xs rounded-lg whitespace-nowrap shrink-0",
                selectedCategory === cat && "bg-primary/10 text-primary"
              )}
            >
              {cat}
            </Button>
          ))}
        </div>
      </motion.div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {filteredTemplates.map((template: any) => (
          <motion.div key={template.id} variants={item}>
            <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover h-full flex flex-col">
              <CardContent className="p-4 sm:p-5 flex-1">
                <div className="flex justify-between items-start mb-3 sm:mb-4">
                  <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl">
                    <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEditDialog(template)}>Editar</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(template.id)}>Excluir</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <Badge variant="outline" className="mb-2 sm:mb-3 text-[9px] sm:text-[10px] font-medium border-border/40 bg-muted/20">
                  {template.category || "Geral"}
                </Badge>

                <h3 className="text-sm sm:text-base font-bold font-heading mb-1 sm:mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {template.title}
                </h3>
                <p className="text-[10px] sm:text-xs text-muted-foreground line-clamp-2">
                  {template.content?.substring(0, 100) || "Sem descrição"}
                </p>
              </CardContent>
              <CardFooter className="bg-muted/10 p-2 sm:p-3 border-t border-border/30 gap-2">
                <Button 
                  variant="outline" 
                  className="flex-1 h-8 sm:h-9 text-[10px] sm:text-xs font-medium border-border/50 rounded-lg sm:rounded-xl"
                  onClick={() => handleUseTemplate(template)}
                >
                  <Copy className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-1 sm:mr-1.5" /> Copiar
                </Button>
                <Button 
                  variant="ghost" 
                  className="flex-1 h-8 sm:h-9 text-[10px] sm:text-xs font-medium hover:bg-primary hover:text-white rounded-lg sm:rounded-xl"
                  onClick={() => openEditDialog(template)}
                >
                  Editar <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 ml-1 sm:ml-1.5" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
        {filteredTemplates.length === 0 && (
          <div className="col-span-full text-center py-12">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhum template encontrado</p>
            <Button onClick={openCreateDialog} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" /> Criar Template
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? "Editar Template" : "Novo Template"}</DialogTitle>
            <DialogDescription>
              {editingTemplate ? "Edite as informações do seu template." : "Crie um novo template para acelerar seu trabalho."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Categoria</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.slice(1).map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="content">Conteúdo</Label>
              <Textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                rows={8}
                placeholder="Digite o conteúdo do template..."
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingTemplate ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
