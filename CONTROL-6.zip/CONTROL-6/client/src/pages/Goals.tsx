import { useState } from "react";
import { useGoals, useCreateGoal, useUpdateGoal, useDeleteGoal } from "@/hooks/use-api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Trophy, TrendingUp, Plus, Zap, MoreHorizontal, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Goals() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    target: "",
    current: "",
    unit: "",
    deadline: "",
  });

  const { data: goals = [], isLoading } = useGoals();
  const createMutation = useCreateGoal();
  const updateMutation = useUpdateGoal();
  const deleteMutation = useDeleteGoal();

  const totalGoals = goals.length;
  const safeProgress = (current: number, target: number) => target > 0 ? (current / target) : 0;
  const completedGoals = goals.filter((g: any) => safeProgress(parseFloat(g.current || 0), parseFloat(g.target || 1)) >= 1).length;
  const avgProgress = totalGoals > 0 ? Math.round(goals.reduce((acc: number, g: any) => acc + Math.min(safeProgress(parseFloat(g.current || 0), parseFloat(g.target || 1)) * 100, 100), 0) / totalGoals) : 0;

  const resetForm = () => {
    setFormData({ title: "", description: "", target: "", current: "", unit: "", deadline: "" });
    setEditingGoal(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (goal: any) => {
    setFormData({
      title: goal.title,
      description: goal.description || "",
      target: goal.target || "",
      current: goal.current || "",
      unit: goal.unit || "",
      deadline: goal.deadline ? new Date(goal.deadline).toISOString().split('T')[0] : "",
    });
    setEditingGoal(goal);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        deadline: formData.deadline ? new Date(formData.deadline) : null,
      };
      if (editingGoal) {
        await updateMutation.mutateAsync({ id: editingGoal.id, data });
        toast.success("Meta atualizada com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Meta criada com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar meta");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta meta?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Meta excluída com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir meta");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Metas</h1>
            <Trophy className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Acompanhe seu progresso e conquiste objetivos.</p>
        </div>
        <Button onClick={openCreateDialog} className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Meta
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
        <Card className="border-border/40 bg-gradient-to-br from-amber-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
          <CardContent className="p-3 sm:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2.5 sm:p-3.5 bg-amber-500/20 rounded-lg sm:rounded-xl text-amber-400">
              <Trophy className="w-5 h-5 sm:w-7 sm:h-7" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Total de Metas</p>
              <h3 className="text-base sm:text-xl font-bold font-heading">{totalGoals}</h3>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">{completedGoals} concluídas</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2 border-border/40 bg-gradient-to-r from-primary/5 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardContent className="p-3 sm:p-5">
            <div className="flex justify-between items-center mb-2 sm:mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg">
                  <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm">Progresso Geral</h3>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">{completedGoals}/{totalGoals} concluídas</p>
                </div>
              </div>
              <Badge className="bg-primary/15 text-primary border-0 font-bold text-[10px] sm:text-xs">{avgProgress}%</Badge>
            </div>
            <Progress value={avgProgress} className="h-2 sm:h-3 bg-muted/30" />
            <p className="text-[10px] sm:text-xs text-muted-foreground mt-1.5 sm:mt-2">Continue assim! Você está no caminho certo.</p>
          </CardContent>
        </Card>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {goals.map((goal: any, i: number) => {
          const target = parseFloat(goal.target || 1);
          const current = parseFloat(goal.current || 0);
          const progress = Math.min(Math.round(safeProgress(current, target) * 100), 100);
          const isCompleted = progress >= 100;
          
          return (
            <motion.div key={goal.id} variants={item}>
              <Card className={cn(
                "border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-300 card-hover h-full group",
                isCompleted && "border-emerald-500/30"
              )}>
                <CardContent className="p-4 sm:p-6 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-3 sm:mb-4">
                    <div className={cn(
                      "p-2 sm:p-2.5 rounded-lg sm:rounded-xl",
                      isCompleted ? "bg-emerald-500/20 text-emerald-400" : "bg-primary/10 text-primary"
                    )}>
                      {isCompleted ? <Trophy className="w-4 h-4 sm:w-5 sm:h-5" /> : <Target className="w-4 h-4 sm:w-5 sm:h-5" />}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={cn(
                        "text-[9px] sm:text-[10px] font-semibold border-0 px-1.5 sm:px-2 py-0.5",
                        isCompleted 
                          ? "bg-emerald-500/15 text-emerald-400" 
                          : progress >= 75 
                            ? "bg-blue-500/15 text-blue-400"
                            : progress >= 50 
                              ? "bg-amber-500/15 text-amber-400"
                              : "bg-muted text-muted-foreground"
                      )}>
                        {isCompleted ? "Concluída" : `${progress}%`}
                      </Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEditDialog(goal)}>Editar</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(goal.id)}>Excluir</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>

                  <div className="flex-1">
                    <h3 className="font-bold text-sm sm:text-base font-heading mb-1">{goal.title}</h3>
                    {goal.description && <p className="text-[10px] sm:text-xs text-muted-foreground mb-3 sm:mb-4">{goal.description}</p>}
                  </div>

                  <div className="space-y-2 sm:space-y-3">
                    <div className="flex items-center justify-between text-[10px] sm:text-xs">
                      <span className="text-muted-foreground font-medium">{current.toLocaleString('pt-BR')} / {target.toLocaleString('pt-BR')}</span>
                      {goal.unit && <span className="font-bold">{goal.unit}</span>}
                    </div>
                    <Progress 
                      value={progress} 
                      className={cn(
                        "h-2 sm:h-2.5",
                        isCompleted && "[&>div]:bg-emerald-500"
                      )} 
                    />
                    {goal.deadline && (
                      <p className="text-[10px] text-muted-foreground">
                        Prazo: {new Date(goal.deadline).toLocaleDateString('pt-BR')}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {goals.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Target className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhuma meta encontrada</p>
            <Button onClick={openCreateDialog} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" /> Adicionar Meta
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingGoal ? "Editar Meta" : "Nova Meta"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="current">Atual</Label>
                <Input
                  id="current"
                  type="number"
                  step="0.01"
                  value={formData.current}
                  onChange={(e) => setFormData({ ...formData, current: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="target">Meta *</Label>
                <Input
                  id="target"
                  type="number"
                  step="0.01"
                  value={formData.target}
                  onChange={(e) => setFormData({ ...formData, target: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unit">Unidade</Label>
                <Input
                  id="unit"
                  value={formData.unit}
                  onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                  placeholder="R$, %"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deadline">Prazo</Label>
              <Input
                id="deadline"
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingGoal ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
