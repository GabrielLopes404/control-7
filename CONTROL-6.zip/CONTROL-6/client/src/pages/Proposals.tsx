import { useState } from "react";
import { useProposals, useClients, useCreateProposal, useUpdateProposal, useDeleteProposal } from "@/hooks/use-api";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, FileText, Send, Download, MoreHorizontal, Calendar, Sparkles, ArrowRight, Check, X, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Proposals() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProposal, setEditingProposal] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    clientId: "",
    value: "",
    status: "draft",
    validUntil: "",
  });

  const { data: proposals = [], isLoading } = useProposals();
  const { data: clients = [] } = useClients();
  const createMutation = useCreateProposal();
  const updateMutation = useUpdateProposal();
  const deleteMutation = useDeleteProposal();

  const filteredProposals = proposals.filter(
    (prop: any) =>
      prop.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "accepted": return { label: "Aceita", color: "bg-emerald-500/15 text-emerald-400", icon: Check };
      case "rejected": return { label: "Rejeitada", color: "bg-red-500/15 text-red-400", icon: X };
      case "sent": return { label: "Enviada", color: "bg-blue-500/15 text-blue-400", icon: Send };
      case "draft": return { label: "Rascunho", color: "bg-muted text-muted-foreground", icon: FileText };
      default: return { label: status, color: "bg-muted text-muted-foreground", icon: FileText };
    }
  };

  const totalValue = proposals.reduce((acc: number, p: any) => acc + parseFloat(p.value || 0), 0);
  const acceptedValue = proposals.filter((p: any) => p.status === 'accepted').reduce((acc: number, p: any) => acc + parseFloat(p.value || 0), 0);

  const resetForm = () => {
    setFormData({ title: "", description: "", clientId: "", value: "", status: "draft", validUntil: "" });
    setEditingProposal(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (proposal: any) => {
    setFormData({
      title: proposal.title,
      description: proposal.description || "",
      clientId: proposal.clientId || "",
      value: proposal.value || "",
      status: proposal.status,
      validUntil: proposal.validUntil ? new Date(proposal.validUntil).toISOString().split('T')[0] : "",
    });
    setEditingProposal(proposal);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        validUntil: formData.validUntil ? new Date(formData.validUntil) : null,
        clientId: formData.clientId || null,
      };
      if (editingProposal) {
        await updateMutation.mutateAsync({ id: editingProposal.id, data });
        toast.success("Proposta atualizada com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Proposta criada com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar proposta");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta proposta?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Proposta excluída com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir proposta");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Propostas</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Crie e envie orçamentos profissionais.</p>
        </div>
        <Button onClick={openCreateDialog} className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Proposta
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{proposals.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg sm:rounded-xl text-emerald-500">
              <Check className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Aceitas</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{proposals.filter((p: any) => p.status === 'accepted').length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <Send className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Valor Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">R$ {totalValue.toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar propostas..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4"
      >
        {filteredProposals.map((proposal: any) => {
          const statusConfig = getStatusConfig(proposal.status);
          const client = clients.find((c: any) => c.id === proposal.clientId);
          const StatusIcon = statusConfig.icon;
          
          return (
            <motion.div key={proposal.id} variants={item}>
              <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover h-full flex flex-col">
                <CardContent className="p-4 sm:p-5 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-3 sm:mb-4">
                    <Badge variant="outline" className={cn("text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5 flex items-center gap-1", statusConfig.color)}>
                      <StatusIcon className="w-3 h-3" />
                      {statusConfig.label}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-6 w-6 sm:h-8 sm:w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity rounded-md sm:rounded-lg">
                          <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl">
                        <DropdownMenuItem onClick={() => openEditDialog(proposal)}>Editar</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(proposal.id)}>Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold leading-tight group-hover:text-primary transition-colors mb-2 line-clamp-2">
                    {proposal.title}
                  </h3>
                  
                  {client && (
                    <p className="text-xs sm:text-sm text-muted-foreground mb-3">{client.name}</p>
                  )}

                  {proposal.description && (
                    <p className="text-[11px] sm:text-xs text-muted-foreground mb-3 line-clamp-2 flex-1">{proposal.description}</p>
                  )}

                  <div className="flex items-center justify-between mt-auto pt-3 border-t border-border/40">
                    {proposal.validUntil && (
                      <div className="flex items-center gap-1.5 text-[10px] sm:text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        <span>Válido até {new Date(proposal.validUntil).toLocaleDateString('pt-BR')}</span>
                      </div>
                    )}
                    <p className="font-mono font-bold text-sm sm:text-base text-emerald-400">R$ {parseFloat(proposal.value || 0).toLocaleString('pt-BR')}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {filteredProposals.length === 0 && (
          <div className="col-span-full text-center py-12">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhuma proposta encontrada</p>
            <Button onClick={openCreateDialog} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" /> Adicionar Proposta
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingProposal ? "Editar Proposta" : "Nova Proposta"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client">Cliente</Label>
              <Select value={formData.clientId} onValueChange={(value) => setFormData({ ...formData, clientId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client: any) => (
                    <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="value">Valor (R$) *</Label>
                <Input
                  id="value"
                  type="number"
                  step="0.01"
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Rascunho</SelectItem>
                    <SelectItem value="sent">Enviada</SelectItem>
                    <SelectItem value="accepted">Aceita</SelectItem>
                    <SelectItem value="rejected">Rejeitada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="validUntil">Válido até</Label>
              <Input
                id="validUntil"
                type="date"
                value={formData.validUntil}
                onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingProposal ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
