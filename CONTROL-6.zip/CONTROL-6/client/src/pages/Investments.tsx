import { useState } from "react";
import { useInvestments, useCreateInvestment, useUpdateInvestment, useDeleteInvestment } from "@/hooks/use-api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, Plus, Wallet, ArrowUpRight, Sparkles, MoreHorizontal, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  PieChart as RePieChart, Pie, Cell, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid
} from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const COLORS = ['#FF00AA', '#3b82f6', '#10b981', '#eab308', '#8b5cf6', '#ef4444'];

const portfolioHistory = [
  { month: 'Jan', value: 10000 },
  { month: 'Fev', value: 11500 },
  { month: 'Mar', value: 11200 },
  { month: 'Abr', value: 13800 },
  { month: 'Mai', value: 15100 },
  { month: 'Jun', value: 16500 },
];

export default function Investments() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingInvestment, setEditingInvestment] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    type: "acoes",
    invested: "",
    currentValue: "",
    return: "",
  });

  const { data: investments = [], isLoading } = useInvestments();
  const createMutation = useCreateInvestment();
  const updateMutation = useUpdateInvestment();
  const deleteMutation = useDeleteInvestment();

  const totalInvested = investments.reduce((acc: number, curr: any) => acc + parseFloat(curr.currentValue || curr.invested || 0), 0);
  const totalProfit = investments.reduce((acc: number, curr: any) => acc + parseFloat(curr.return || 0), 0);
  const totalProfitPercent = totalInvested > 0 ? (totalProfit / (totalInvested - totalProfit)) * 100 : 0;

  const allocationData = investments.reduce((acc: any[], inv: any) => {
    const existing = acc.find((a: any) => a.name === inv.type);
    const value = parseFloat(inv.currentValue || inv.invested || 0);
    if (existing) {
      existing.value += value;
    } else {
      acc.push({ name: inv.type, value });
    }
    return acc;
  }, []);

  const resetForm = () => {
    setFormData({ name: "", type: "acoes", invested: "", currentValue: "", return: "" });
    setEditingInvestment(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (investment: any) => {
    setFormData({
      name: investment.name,
      type: investment.type,
      invested: investment.invested || "",
      currentValue: investment.currentValue || "",
      return: investment.return || "",
    });
    setEditingInvestment(investment);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingInvestment) {
        await updateMutation.mutateAsync({ id: editingInvestment.id, data: formData });
        toast.success("Investimento atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Investimento criado com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar investimento");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este investimento?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Investimento excluído com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir investimento");
    }
  };

  const getTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      'acoes': 'Ações',
      'fii': 'FII',
      'cdb': 'CDB',
      'tesouro': 'Tesouro',
      'cripto': 'Cripto',
      'outros': 'Outros',
    };
    return types[type] || type;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Investimentos</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Acompanhe a evolução do seu patrimônio.</p>
        </div>
        <Button onClick={openCreateDialog} className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white shadow-lg shadow-emerald-500/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Aporte
        </Button>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4"
      >
        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-emerald-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-emerald-500/20 rounded-lg sm:rounded-xl text-emerald-400">
                  <Wallet className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <Badge variant="outline" className="border-0 bg-emerald-500/15 text-emerald-400 text-[9px] sm:text-[10px] font-bold">
                  <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> +{totalProfitPercent.toFixed(1)}%
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Patrimônio Total</p>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5">R$ {totalInvested.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-blue-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-blue-500/20 rounded-lg sm:rounded-xl text-blue-400">
                  <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Lucro Total</p>
              <h3 className={cn("text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5", totalProfit >= 0 ? "text-emerald-400" : "text-red-400")}>
                {totalProfit >= 0 ? '+' : '-'}R$ {Math.abs(totalProfit).toLocaleString('pt-BR')}
              </h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-primary/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-primary/20 rounded-lg sm:rounded-xl text-primary">
                  <DollarSign className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Total de Ativos</p>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold font-heading mt-0.5">{investments.length}</h3>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6">
        <motion.div variants={item} className="lg:col-span-2">
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm sm:text-base">Evolução do Patrimônio</CardTitle>
            </CardHeader>
            <CardContent className="h-[200px] sm:h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[...portfolioHistory, { month: 'Jul', value: totalInvested || 17000 }]} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorPortfolio" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.4}/>
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      borderColor: 'hsl(var(--border))', 
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                    formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Valor']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorPortfolio)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm sm:text-base">Alocação</CardTitle>
            </CardHeader>
            <CardContent className="h-[200px] sm:h-[250px]">
              {allocationData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie
                      data={allocationData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={70}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {allocationData.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`} />
                  </RePieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                  Adicione investimentos para ver a alocação
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
        {investments.map((inv: any, index: number) => {
          const profit = parseFloat(inv.return || 0);
          const currentValue = parseFloat(inv.currentValue || inv.invested || 0);
          
          return (
            <motion.div key={inv.id} variants={item}>
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all group">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl" style={{ backgroundColor: `${COLORS[index % COLORS.length]}20` }}>
                        <TrendingUp className="w-5 h-5" style={{ color: COLORS[index % COLORS.length] }} />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm">{inv.name}</h4>
                        <Badge variant="secondary" className="text-[10px] mt-1">{getTypeLabel(inv.type)}</Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditDialog(inv)}>Editar</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(inv.id)}>Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Valor Atual</p>
                      <p className="font-mono font-bold text-lg">R$ {currentValue.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-muted-foreground uppercase">Retorno</p>
                      <p className={cn("font-mono font-bold text-sm", profit >= 0 ? "text-emerald-400" : "text-red-400")}>
                        {profit >= 0 ? '+' : '-'}R$ {Math.abs(profit).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
        {investments.length === 0 && (
          <div className="col-span-full text-center py-12">
            <TrendingUp className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhum investimento encontrado</p>
            <Button onClick={openCreateDialog} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" /> Adicionar Investimento
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingInvestment ? "Editar Investimento" : "Novo Investimento"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Tipo</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="acoes">Ações</SelectItem>
                  <SelectItem value="fii">FII</SelectItem>
                  <SelectItem value="cdb">CDB</SelectItem>
                  <SelectItem value="tesouro">Tesouro Direto</SelectItem>
                  <SelectItem value="cripto">Criptomoedas</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invested">Valor Investido (R$)</Label>
                <Input
                  id="invested"
                  type="number"
                  step="0.01"
                  value={formData.invested}
                  onChange={(e) => setFormData({ ...formData, invested: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currentValue">Valor Atual (R$)</Label>
                <Input
                  id="currentValue"
                  type="number"
                  step="0.01"
                  value={formData.currentValue}
                  onChange={(e) => setFormData({ ...formData, currentValue: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="return">Retorno (R$)</Label>
              <Input
                id="return"
                type="number"
                step="0.01"
                value={formData.return}
                onChange={(e) => setFormData({ ...formData, return: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingInvestment ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
