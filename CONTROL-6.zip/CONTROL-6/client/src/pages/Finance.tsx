import { useState } from "react";
import { useInvoices, useExpenses, useCreateInvoice, useUpdateInvoice, useDeleteInvoice, useCreateExpense, useUpdateExpense, useDeleteExpense } from "@/hooks/use-api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Download, MoreHorizontal, Wallet, PieChart as PieChartIcon, Activity, Sparkles, Loader2, Check, X, Clock, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Finance() {
  const [isInvoiceDialogOpen, setIsInvoiceDialogOpen] = useState(false);
  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<any>(null);
  const [editingExpense, setEditingExpense] = useState<any>(null);
  const [invoiceForm, setInvoiceForm] = useState({
    description: "",
    amount: "",
    status: "pending",
    date: new Date().toISOString().split('T')[0],
  });
  const [expenseForm, setExpenseForm] = useState({
    description: "",
    amount: "",
    category: "",
    date: new Date().toISOString().split('T')[0],
  });

  const { data: invoices = [], isLoading: loadingInvoices } = useInvoices();
  const { data: expenses = [], isLoading: loadingExpenses } = useExpenses();
  const createInvoiceMutation = useCreateInvoice();
  const updateInvoiceMutation = useUpdateInvoice();
  const deleteInvoiceMutation = useDeleteInvoice();
  const createExpenseMutation = useCreateExpense();
  const updateExpenseMutation = useUpdateExpense();
  const deleteExpenseMutation = useDeleteExpense();

  const isLoading = loadingInvoices || loadingExpenses;

  const totalIncome = invoices
    .filter((i: any) => i.status === "paid")
    .reduce((acc: number, curr: any) => acc + parseFloat(curr.amount || 0), 0);
  
  const totalPending = invoices
    .filter((i: any) => i.status === "pending" || i.status === "overdue")
    .reduce((acc: number, curr: any) => acc + parseFloat(curr.amount || 0), 0);

  const totalExpenses = expenses.reduce((acc: number, curr: any) => acc + parseFloat(curr.amount || 0), 0);
  const balance = totalIncome - totalExpenses;

  const cashflowData = [
    { name: 'Jan', income: 4000, expense: 2400 },
    { name: 'Fev', income: 3000, expense: 1398 },
    { name: 'Mar', income: 5000, expense: 2800 },
    { name: 'Abr', income: 4780, expense: 3908 },
    { name: 'Mai', income: 6890, expense: 4800 },
    { name: 'Jun', income: 5390, expense: 3800 },
    { name: 'Jul', income: totalIncome || 7490, expense: totalExpenses || 4300 },
  ];

  const resetInvoiceForm = () => {
    setInvoiceForm({ description: "", amount: "", status: "pending", date: new Date().toISOString().split('T')[0] });
    setEditingInvoice(null);
  };

  const resetExpenseForm = () => {
    setExpenseForm({ description: "", amount: "", category: "", date: new Date().toISOString().split('T')[0] });
    setEditingExpense(null);
  };

  const openCreateInvoiceDialog = () => {
    resetInvoiceForm();
    setIsInvoiceDialogOpen(true);
  };

  const openEditInvoiceDialog = (invoice: any) => {
    setInvoiceForm({
      description: invoice.description || "",
      amount: invoice.amount || "",
      status: invoice.status,
      date: invoice.date ? new Date(invoice.date).toISOString().split('T')[0] : "",
    });
    setEditingInvoice(invoice);
    setIsInvoiceDialogOpen(true);
  };

  const openCreateExpenseDialog = () => {
    resetExpenseForm();
    setIsExpenseDialogOpen(true);
  };

  const openEditExpenseDialog = (expense: any) => {
    setExpenseForm({
      description: expense.description || "",
      amount: expense.amount || "",
      category: expense.category || "",
      date: expense.date ? new Date(expense.date).toISOString().split('T')[0] : "",
    });
    setEditingExpense(expense);
    setIsExpenseDialogOpen(true);
  };

  const handleInvoiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...invoiceForm,
        date: new Date(invoiceForm.date),
      };
      if (editingInvoice) {
        await updateInvoiceMutation.mutateAsync({ id: editingInvoice.id, data });
        toast.success("Fatura atualizada com sucesso!");
      } else {
        await createInvoiceMutation.mutateAsync(data);
        toast.success("Fatura criada com sucesso!");
      }
      setIsInvoiceDialogOpen(false);
      resetInvoiceForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar fatura");
    }
  };

  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...expenseForm,
        date: new Date(expenseForm.date),
      };
      if (editingExpense) {
        await updateExpenseMutation.mutateAsync({ id: editingExpense.id, data });
        toast.success("Despesa atualizada com sucesso!");
      } else {
        await createExpenseMutation.mutateAsync(data);
        toast.success("Despesa criada com sucesso!");
      }
      setIsExpenseDialogOpen(false);
      resetExpenseForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar despesa");
    }
  };

  const handleDeleteInvoice = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta fatura?")) return;
    try {
      await deleteInvoiceMutation.mutateAsync(id);
      toast.success("Fatura excluída com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir fatura");
    }
  };

  const handleDeleteExpense = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta despesa?")) return;
    try {
      await deleteExpenseMutation.mutateAsync(id);
      toast.success("Despesa excluída com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir despesa");
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "paid": return { label: "Pago", color: "bg-emerald-500/15 text-emerald-400", icon: Check };
      case "pending": return { label: "Pendente", color: "bg-amber-500/15 text-amber-400", icon: Clock };
      case "overdue": return { label: "Atrasado", color: "bg-red-500/15 text-red-400", icon: AlertCircle };
      default: return { label: status, color: "bg-muted text-muted-foreground", icon: Clock };
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Financeiro</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Controle de receitas, despesas e fluxo de caixa.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={openCreateExpenseDialog} variant="outline" size="sm" className="h-8 sm:h-10 text-xs sm:text-sm border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-xl">
            <TrendingDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Despesa
          </Button>
          <Button onClick={openCreateInvoiceDialog} size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white shadow-lg shadow-emerald-500/25 border-0 rounded-xl">
            <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Receita
          </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4"
      >
        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-emerald-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-emerald-500/20 rounded-lg sm:rounded-xl text-emerald-400">
                  <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-emerald-500/15 text-emerald-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  <ArrowUpRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> Receita
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Receita</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalIncome.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-blue-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-blue-500/20 rounded-lg sm:rounded-xl text-blue-400">
                  <PieChartIcon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-blue-500/15 text-blue-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  Pendente
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">A Receber</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalPending.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-red-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-red-500/20 rounded-lg sm:rounded-xl text-red-400">
                  <TrendingDown className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className="border-0 bg-red-500/15 text-red-400 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5">
                  <ArrowDownRight className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5" /> Despesa
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Despesas</p>
              <h3 className="text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5">R$ {totalExpenses.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-gradient-to-br from-purple-500/10 via-card/60 to-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden card-hover">
            <CardContent className="p-3 sm:p-4 lg:p-5">
              <div className="flex items-start justify-between mb-2 sm:mb-3">
                <div className="p-2 sm:p-2.5 bg-purple-500/20 rounded-lg sm:rounded-xl text-purple-400">
                  <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <Badge variant="outline" className={cn(
                  "border-0 text-[9px] sm:text-[10px] font-bold px-1 sm:px-1.5",
                  balance >= 0 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                )}>
                  {balance >= 0 ? "+" : "-"}
                </Badge>
              </div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase font-semibold tracking-wider">Balanço</p>
              <h3 className={cn("text-base sm:text-xl lg:text-2xl font-bold font-heading mt-0.5", balance >= 0 ? "text-emerald-400" : "text-red-400")}>
                R$ {Math.abs(balance).toLocaleString('pt-BR')}
              </h3>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <Card className="lg:col-span-2 border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm sm:text-base">Fluxo de Caixa</CardTitle>
          </CardHeader>
          <CardContent className="h-[200px] sm:h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={cashflowData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="100%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    borderColor: 'hsl(var(--border))', 
                    borderRadius: '12px',
                    fontSize: '12px'
                  }}
                />
                <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" name="Receita" />
                <Area type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorExpense)" name="Despesa" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm sm:text-base">Resumo Rápido</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
              <p className="text-xs text-muted-foreground">Faturas Pagas</p>
              <p className="text-lg font-bold text-emerald-400">{invoices.filter((i: any) => i.status === 'paid').length}</p>
            </div>
            <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
              <p className="text-xs text-muted-foreground">Faturas Pendentes</p>
              <p className="text-lg font-bold text-amber-400">{invoices.filter((i: any) => i.status === 'pending').length}</p>
            </div>
            <div className="p-3 bg-red-500/10 rounded-lg border border-red-500/20">
              <p className="text-xs text-muted-foreground">Total Despesas</p>
              <p className="text-lg font-bold text-red-400">{expenses.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="invoices" className="space-y-4">
        <TabsList className="bg-card/40 border border-border/40 rounded-xl p-1">
          <TabsTrigger value="invoices" className="rounded-lg">Faturas ({invoices.length})</TabsTrigger>
          <TabsTrigger value="expenses" className="rounded-lg">Despesas ({expenses.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="invoices" className="space-y-4">
          <motion.div variants={container} initial="hidden" animate="show" className="grid gap-3">
            {invoices.map((invoice: any) => {
              const statusConfig = getStatusConfig(invoice.status);
              const StatusIcon = statusConfig.icon;
              return (
                <motion.div key={invoice.id} variants={item}>
                  <Card className="border-border/40 bg-card/60 rounded-xl overflow-hidden hover:border-primary/30 transition-all">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={cn("p-2.5 rounded-xl", invoice.status === 'paid' ? 'bg-emerald-500/10' : 'bg-amber-500/10')}>
                          <StatusIcon className={cn("w-5 h-5", invoice.status === 'paid' ? 'text-emerald-400' : 'text-amber-400')} />
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm">{invoice.description || 'Fatura'}</h4>
                          <p className="text-xs text-muted-foreground">
                            {invoice.date ? new Date(invoice.date).toLocaleDateString('pt-BR') : '-'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className={cn("text-[10px] border-0", statusConfig.color)}>
                          {statusConfig.label}
                        </Badge>
                        <span className="font-mono font-bold text-sm">R$ {parseFloat(invoice.amount || 0).toLocaleString('pt-BR')}</span>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditInvoiceDialog(invoice)}>Editar</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" onClick={() => handleDeleteInvoice(invoice.id)}>Excluir</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
            {invoices.length === 0 && (
              <div className="text-center py-12">
                <Wallet className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">Nenhuma fatura encontrada</p>
                <Button onClick={openCreateInvoiceDialog} variant="outline" className="mt-4">
                  <Plus className="w-4 h-4 mr-2" /> Adicionar Fatura
                </Button>
              </div>
            )}
          </motion.div>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-4">
          <motion.div variants={container} initial="hidden" animate="show" className="grid gap-3">
            {expenses.map((expense: any) => (
              <motion.div key={expense.id} variants={item}>
                <Card className="border-border/40 bg-card/60 rounded-xl overflow-hidden hover:border-red-500/30 transition-all">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-2.5 rounded-xl bg-red-500/10">
                        <TrendingDown className="w-5 h-5 text-red-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-sm">{expense.description || 'Despesa'}</h4>
                        <p className="text-xs text-muted-foreground">
                          {expense.category && <Badge variant="secondary" className="mr-2 text-[10px]">{expense.category}</Badge>}
                          {expense.date ? new Date(expense.date).toLocaleDateString('pt-BR') : '-'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-mono font-bold text-sm text-red-400">-R$ {parseFloat(expense.amount || 0).toLocaleString('pt-BR')}</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEditExpenseDialog(expense)}>Editar</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => handleDeleteExpense(expense.id)}>Excluir</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            {expenses.length === 0 && (
              <div className="text-center py-12">
                <TrendingDown className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">Nenhuma despesa encontrada</p>
                <Button onClick={openCreateExpenseDialog} variant="outline" className="mt-4">
                  <Plus className="w-4 h-4 mr-2" /> Adicionar Despesa
                </Button>
              </div>
            )}
          </motion.div>
        </TabsContent>
      </Tabs>

      <Dialog open={isInvoiceDialogOpen} onOpenChange={setIsInvoiceDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingInvoice ? "Editar Fatura" : "Nova Fatura"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleInvoiceSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="description">Descrição *</Label>
              <Input
                id="description"
                value={invoiceForm.description}
                onChange={(e) => setInvoiceForm({ ...invoiceForm, description: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Valor (R$) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={invoiceForm.amount}
                  onChange={(e) => setInvoiceForm({ ...invoiceForm, amount: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={invoiceForm.status} onValueChange={(value) => setInvoiceForm({ ...invoiceForm, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="paid">Pago</SelectItem>
                    <SelectItem value="overdue">Atrasado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Data</Label>
              <Input
                id="date"
                type="date"
                value={invoiceForm.date}
                onChange={(e) => setInvoiceForm({ ...invoiceForm, date: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsInvoiceDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createInvoiceMutation.isPending || updateInvoiceMutation.isPending}>
                {(createInvoiceMutation.isPending || updateInvoiceMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingInvoice ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingExpense ? "Editar Despesa" : "Nova Despesa"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleExpenseSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="exp-description">Descrição *</Label>
              <Input
                id="exp-description"
                value={expenseForm.description}
                onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="exp-amount">Valor (R$) *</Label>
                <Input
                  id="exp-amount"
                  type="number"
                  step="0.01"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Categoria</Label>
                <Input
                  id="category"
                  value={expenseForm.category}
                  onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })}
                  placeholder="Ex: Software, Marketing"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="exp-date">Data</Label>
              <Input
                id="exp-date"
                type="date"
                value={expenseForm.date}
                onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsExpenseDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createExpenseMutation.isPending || updateExpenseMutation.isPending}>
                {(createExpenseMutation.isPending || updateExpenseMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingExpense ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
