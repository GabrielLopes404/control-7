import { useState } from "react";
import { useTasks, useProjects, useCreateTask, useUpdateTask, useDeleteTask } from "@/hooks/use-api";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, MoreHorizontal, Calendar, Clock, Play, GripVertical, Sparkles, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  defaultDropAnimationSideEffects,
  DragStartEvent,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

function SortableTask({ task, projectTitle, onEdit, onDelete }: { task: any, projectTitle: string | undefined, onEdit: () => void, onDelete: () => void }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: task.id, data: { task } });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const getPriorityConfig = (priority: string) => {
    switch (priority) {
      case "high": return { label: "Alta", color: "bg-red-500/15 text-red-400" };
      case "medium": return { label: "Média", color: "bg-amber-500/15 text-amber-400" };
      case "low": return { label: "Baixa", color: "bg-blue-500/15 text-blue-400" };
      default: return { label: priority, color: "bg-muted text-muted-foreground" };
    }
  };

  const priorityConfig = getPriorityConfig(task.priority);

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      className="bg-card/80 border border-border/40 p-2.5 sm:p-3.5 rounded-lg sm:rounded-xl shadow-sm hover:border-primary/30 cursor-grab active:cursor-grabbing mb-2 sm:mb-2.5 group transition-all card-hover relative"
    >
      <div {...attributes} {...listeners} className="absolute top-2 sm:top-3 left-0.5 sm:left-1 opacity-0 group-hover:opacity-50 cursor-grab">
        <GripVertical className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" />
      </div>
      <div className="pl-3 sm:pl-4">
        <div className="flex justify-between items-start mb-2 sm:mb-2.5">
          <Badge variant="outline" className={cn("text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5", priorityConfig.color)}>
            {priorityConfig.label}
          </Badge>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-5 w-5 sm:h-6 sm:w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity rounded-md">
                <MoreHorizontal className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>Editar</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive" onClick={onDelete}>Excluir</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <h4 className="font-semibold text-xs sm:text-sm mb-1 sm:mb-1.5 leading-tight line-clamp-2">{task.title}</h4>
        <p className="text-[10px] sm:text-xs text-muted-foreground mb-2 sm:mb-3 line-clamp-1">{projectTitle || 'Sem projeto'}</p>
        
        <div className="flex items-center justify-between">
          {task.dueDate && (
            <div className="flex items-center gap-1 sm:gap-1.5 text-[10px] sm:text-xs text-muted-foreground bg-muted/20 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-md">
              <Calendar className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
              <span>{new Date(task.dueDate).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}</span>
            </div>
          )}
          {task.timeTracked > 0 && (
            <div className="flex items-center gap-0.5 sm:gap-1 text-[10px] sm:text-xs font-mono text-primary bg-primary/10 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-md">
              <Clock className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
              <span>{Math.floor(task.timeTracked / 60)}h</span>
            </div>
          )}
        </div>
        
        {task.isTracking && (
          <div className="mt-2 sm:mt-2.5 flex items-center justify-center gap-1 sm:gap-1.5 bg-primary/15 text-primary text-[10px] sm:text-xs py-1 sm:py-1.5 rounded-md sm:rounded-lg font-semibold">
            <Play className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current animate-pulse" />
            Em andamento...
          </div>
        )}
      </div>
    </div>
  );
}

function KanbanColumn({ id, title, tasks, projects, onAddTask, onEditTask, onDeleteTask }: { id: string, title: string, tasks: any[], projects: any[], onAddTask: (status: string) => void, onEditTask: (task: any) => void, onDeleteTask: (id: string) => void }) {
  const getColumnColor = (colId: string) => {
    switch (colId) {
      case "todo": return "bg-blue-500";
      case "in_progress": return "bg-amber-500";
      case "review": return "bg-purple-500";
      case "done": return "bg-emerald-500";
      default: return "bg-muted-foreground";
    }
  };

  return (
    <div className="flex-1 min-w-[260px] sm:min-w-[300px] flex flex-col h-full bg-muted/10 rounded-xl sm:rounded-2xl border border-border/40 overflow-hidden">
      <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3 border-b border-border/40 bg-card/30">
        <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-1.5 sm:gap-2">
          <span className={cn("w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full", getColumnColor(id))} />
          {title}
        </h3>
        <Badge variant="secondary" className="text-[10px] sm:text-xs bg-muted/50 font-semibold h-5 sm:h-6 px-1.5 sm:px-2">{tasks.length}</Badge>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2 sm:p-3 hide-scrollbar-mobile">
        <SortableContext 
          id={id}
          items={tasks.map(t => t.id)} 
          strategy={verticalListSortingStrategy}
        >
          {tasks.map(task => (
            <SortableTask 
              key={task.id} 
              task={task} 
              projectTitle={projects.find((p: any) => p.id === task.projectId)?.title}
              onEdit={() => onEditTask(task)}
              onDelete={() => onDeleteTask(task.id)}
            />
          ))}
        </SortableContext>
        {tasks.length === 0 && (
          <div className="h-16 sm:h-24 flex items-center justify-center border-2 border-dashed border-border/40 rounded-lg sm:rounded-xl text-muted-foreground text-[10px] sm:text-xs">
            Arraste tarefas aqui
          </div>
        )}
      </div>
      
      <div className="p-2 sm:p-3 border-t border-border/40">
        <Button onClick={() => onAddTask(id)} variant="ghost" className="w-full h-8 sm:h-9 text-[10px] sm:text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/30 rounded-md sm:rounded-lg gap-1 sm:gap-1.5">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Adicionar
        </Button>
      </div>
    </div>
  );
}

export default function Tasks() {
  const { data: tasks = [], isLoading } = useTasks();
  const { data: projects = [] } = useProjects();
  const createMutation = useCreateTask();
  const updateMutation = useUpdateTask();
  const deleteMutation = useDeleteTask();

  const [activeId, setActiveId] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    projectId: "",
    status: "todo",
    priority: "medium",
    dueDate: "",
  });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const columns = [
    { id: 'todo', title: 'A Fazer' },
    { id: 'in_progress', title: 'Andamento' },
    { id: 'review', title: 'Revisão' },
    { id: 'done', title: 'Concluído' },
  ];

  const resetForm = () => {
    setFormData({ title: "", description: "", projectId: "", status: "todo", priority: "medium", dueDate: "" });
    setEditingTask(null);
  };

  const openCreateDialog = (status: string = "todo") => {
    resetForm();
    setFormData(prev => ({ ...prev, status }));
    setIsDialogOpen(true);
  };

  const openEditDialog = (task: any) => {
    setFormData({
      title: task.title,
      description: task.description || "",
      projectId: task.projectId || "",
      status: task.status,
      priority: task.priority,
      dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : "",
    });
    setEditingTask(task);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        dueDate: formData.dueDate ? new Date(formData.dueDate) : null,
        projectId: formData.projectId || null,
      };
      if (editingTask) {
        await updateMutation.mutateAsync({ id: editingTask.id, data });
        toast.success("Tarefa atualizada com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Tarefa criada com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar tarefa");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta tarefa?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Tarefa excluída com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir tarefa");
    }
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) {
      setActiveId(null);
      return;
    }

    const activeTask = tasks.find((t: any) => t.id === active.id);
    const overId = over.id;
    
    let newStatus = overId as string;
    
    const overTask = tasks.find((t: any) => t.id === overId);
    if (overTask) {
      newStatus = overTask.status;
    } else if (!columns.find(c => c.id === overId)) {
      setActiveId(null);
      return;
    }

    if (activeTask && activeTask.status !== newStatus) {
      try {
        await updateMutation.mutateAsync({ id: active.id as string, data: { status: newStatus } });
      } catch (error) {
        toast.error("Erro ao mover tarefa");
      }
    }

    setActiveId(null);
  };

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t: any) => t.status === 'done').length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-100px)] sm:h-[calc(100vh-100px)]">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between mb-4 sm:mb-6 shrink-0">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Kanban</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">
            Gerencie o fluxo de trabalho • <span className="text-foreground font-medium">{completedTasks}/{totalTasks}</span> concluídas
          </p>
        </div>
        <Button onClick={() => openCreateDialog()} size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Nova Tarefa
        </Button>
      </div>

      <DndContext 
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="flex-1 flex overflow-x-auto gap-2 sm:gap-4 pb-4 hide-scrollbar-mobile">
          {columns.map(col => (
            <KanbanColumn 
              key={col.id} 
              id={col.id} 
              title={col.title} 
              tasks={tasks.filter((t: any) => t.status === col.id)}
              projects={projects}
              onAddTask={openCreateDialog}
              onEditTask={openEditDialog}
              onDeleteTask={handleDelete}
            />
          ))}
        </div>

        <DragOverlay dropAnimation={{ sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.5' } } }) }}>
          {activeId ? (
            <div className="bg-card border border-primary/30 p-2.5 sm:p-3.5 rounded-lg sm:rounded-xl shadow-2xl cursor-grabbing rotate-2 w-[240px] sm:w-[280px]">
              <h4 className="font-semibold text-xs sm:text-sm">{tasks.find((t: any) => t.id === activeId)?.title}</h4>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingTask ? "Editar Tarefa" : "Nova Tarefa"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="project">Projeto</Label>
              <Select value={formData.projectId} onValueChange={(value) => setFormData({ ...formData, projectId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um projeto" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project: any) => (
                    <SelectItem key={project.id} value={project.id}>{project.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todo">A Fazer</SelectItem>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="review">Revisão</SelectItem>
                    <SelectItem value="done">Concluído</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="priority">Prioridade</Label>
                <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Baixa</SelectItem>
                    <SelectItem value="medium">Média</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Data de Entrega</Label>
              <Input
                id="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingTask ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
