import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";
import { storage } from "./storage";
import type { Notification } from "@shared/schema";

interface WebSocketClient extends WebSocket {
  userId?: string;
  isAlive?: boolean;
}

class NotificationWebSocketServer {
  private wss: WebSocketServer;
  private clients: Map<string, Set<WebSocketClient>> = new Map();

  constructor(httpServer: Server) {
    this.wss = new WebSocketServer({ server: httpServer, path: "/ws" });

    this.wss.on("connection", (ws: WebSocketClient) => {
      ws.isAlive = true;

      ws.on("pong", () => {
        ws.isAlive = true;
      });

      ws.on("message", async (message: Buffer) => {
        try {
          const data = JSON.parse(message.toString());
          
          if (data.type === "auth" && data.userId) {
            ws.userId = data.userId;
            
            if (!this.clients.has(data.userId)) {
              this.clients.set(data.userId, new Set());
            }
            this.clients.get(data.userId)!.add(ws);

            const notifications = await storage.getNotifications(data.userId);
            ws.send(JSON.stringify({
              type: "notifications",
              data: notifications
            }));
          }

          if (data.type === "markRead" && data.notificationId) {
            await storage.markNotificationRead(data.notificationId);
            this.sendToUser(ws.userId!, {
              type: "notificationRead",
              data: { id: data.notificationId }
            });
          }

          if (data.type === "markAllRead" && ws.userId) {
            await storage.markAllNotificationsRead(ws.userId);
            this.sendToUser(ws.userId, {
              type: "allNotificationsRead",
              data: {}
            });
          }
        } catch (error) {
          console.error("WebSocket message error:", error);
        }
      });

      ws.on("close", () => {
        if (ws.userId) {
          const userClients = this.clients.get(ws.userId);
          if (userClients) {
            userClients.delete(ws);
            if (userClients.size === 0) {
              this.clients.delete(ws.userId);
            }
          }
        }
      });

      ws.on("error", (error) => {
        console.error("WebSocket error:", error);
      });
    });

    const heartbeat = setInterval(() => {
      this.wss.clients.forEach((ws: WebSocketClient) => {
        if (ws.isAlive === false) {
          return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000);

    this.wss.on("close", () => {
      clearInterval(heartbeat);
    });
  }

  sendToUser(userId: string, message: object) {
    const userClients = this.clients.get(userId);
    if (userClients) {
      const messageStr = JSON.stringify(message);
      userClients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(messageStr);
        }
      });
    }
  }

  async createNotification(notification: Notification) {
    this.sendToUser(notification.userId, {
      type: "newNotification",
      data: notification
    });
  }

  broadcast(message: object) {
    const messageStr = JSON.stringify(message);
    this.wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }
}

let wsServer: NotificationWebSocketServer | null = null;

export function initWebSocket(httpServer: Server): NotificationWebSocketServer {
  if (!wsServer) {
    wsServer = new NotificationWebSocketServer(httpServer);
  }
  return wsServer;
}

export function getWebSocketServer(): NotificationWebSocketServer | null {
  return wsServer;
}
