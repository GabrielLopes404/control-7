import { storage } from "./storage";
import { getWebSocketServer } from "./websocket";

type NotificationType = 
  | 'project_created' | 'project_updated' | 'project_completed'
  | 'task_created' | 'task_updated' | 'task_completed'
  | 'invoice_created' | 'invoice_paid'
  | 'expense_created'
  | 'proposal_created' | 'proposal_sent' | 'proposal_accepted' | 'proposal_rejected'
  | 'goal_created' | 'goal_completed'
  | 'chat_message'
  | 'calendar_event_created'
  | 'client_created';

interface NotificationPayload {
  type: NotificationType;
  userId: string;
  entityId?: string;
  entityName?: string;
  additionalInfo?: Record<string, any>;
}

const notificationTemplates: Record<NotificationType, { title: string; message: (payload: NotificationPayload) => string }> = {
  project_created: {
    title: "Novo Projeto",
    message: (p) => `Projeto "${p.entityName}" foi criado com sucesso.`
  },
  project_updated: {
    title: "Projeto Atualizado",
    message: (p) => `O projeto "${p.entityName}" foi atualizado.`
  },
  project_completed: {
    title: "Projeto Concluído",
    message: (p) => `Parabéns! O projeto "${p.entityName}" foi concluído.`
  },
  task_created: {
    title: "Nova Tarefa",
    message: (p) => `Tarefa "${p.entityName}" foi criada.`
  },
  task_updated: {
    title: "Tarefa Atualizada",
    message: (p) => `A tarefa "${p.entityName}" foi atualizada.`
  },
  task_completed: {
    title: "Tarefa Concluída",
    message: (p) => `A tarefa "${p.entityName}" foi marcada como concluída.`
  },
  invoice_created: {
    title: "Nova Fatura",
    message: (p) => `Fatura de R$ ${p.additionalInfo?.amount || '0,00'} foi criada.`
  },
  invoice_paid: {
    title: "Fatura Paga",
    message: (p) => `Pagamento de R$ ${p.additionalInfo?.amount || '0,00'} foi recebido!`
  },
  expense_created: {
    title: "Nova Despesa",
    message: (p) => `Despesa "${p.entityName}" de R$ ${p.additionalInfo?.amount || '0,00'} foi registrada.`
  },
  proposal_created: {
    title: "Nova Proposta",
    message: (p) => `Proposta "${p.entityName}" foi criada.`
  },
  proposal_sent: {
    title: "Proposta Enviada",
    message: (p) => `A proposta "${p.entityName}" foi enviada para o cliente.`
  },
  proposal_accepted: {
    title: "Proposta Aceita!",
    message: (p) => `A proposta "${p.entityName}" foi aceita pelo cliente!`
  },
  proposal_rejected: {
    title: "Proposta Recusada",
    message: (p) => `A proposta "${p.entityName}" foi recusada pelo cliente.`
  },
  goal_created: {
    title: "Nova Meta",
    message: (p) => `Meta "${p.entityName}" foi criada.`
  },
  goal_completed: {
    title: "Meta Alcançada!",
    message: (p) => `Parabéns! Você atingiu a meta "${p.entityName}"!`
  },
  chat_message: {
    title: "Nova Mensagem",
    message: (p) => `${p.additionalInfo?.senderName || 'Alguém'} enviou uma mensagem.`
  },
  calendar_event_created: {
    title: "Novo Evento",
    message: (p) => `Evento "${p.entityName}" foi agendado.`
  },
  client_created: {
    title: "Novo Cliente",
    message: (p) => `Cliente "${p.entityName}" foi adicionado.`
  }
};

export async function createNotificationForEvent(payload: NotificationPayload): Promise<void> {
  try {
    const template = notificationTemplates[payload.type];
    if (!template) {
      console.error(`Unknown notification type: ${payload.type}`);
      return;
    }

    const notification = await storage.createNotification({
      userId: payload.userId,
      title: template.title,
      message: template.message(payload),
      type: payload.type,
      read: false
    });

    const wsServer = getWebSocketServer();
    if (wsServer) {
      wsServer.createNotification(notification);
    }
  } catch (error) {
    console.error(`Failed to create notification for event ${payload.type}:`, error);
  }
}

export function notifyProjectCreated(userId: string, projectName: string, projectId: string) {
  return createNotificationForEvent({
    type: 'project_created',
    userId,
    entityId: projectId,
    entityName: projectName
  });
}

export function notifyProjectCompleted(userId: string, projectName: string, projectId: string) {
  return createNotificationForEvent({
    type: 'project_completed',
    userId,
    entityId: projectId,
    entityName: projectName
  });
}

export function notifyTaskCreated(userId: string, taskName: string, taskId: string) {
  return createNotificationForEvent({
    type: 'task_created',
    userId,
    entityId: taskId,
    entityName: taskName
  });
}

export function notifyTaskCompleted(userId: string, taskName: string, taskId: string) {
  return createNotificationForEvent({
    type: 'task_completed',
    userId,
    entityId: taskId,
    entityName: taskName
  });
}

export function notifyInvoiceCreated(userId: string, amount: string, invoiceId: string) {
  return createNotificationForEvent({
    type: 'invoice_created',
    userId,
    entityId: invoiceId,
    additionalInfo: { amount }
  });
}

export function notifyInvoicePaid(userId: string, amount: string, invoiceId: string) {
  return createNotificationForEvent({
    type: 'invoice_paid',
    userId,
    entityId: invoiceId,
    additionalInfo: { amount }
  });
}

export function notifyProposalCreated(userId: string, proposalName: string, proposalId: string) {
  return createNotificationForEvent({
    type: 'proposal_created',
    userId,
    entityId: proposalId,
    entityName: proposalName
  });
}

export function notifyProposalAccepted(userId: string, proposalName: string, proposalId: string) {
  return createNotificationForEvent({
    type: 'proposal_accepted',
    userId,
    entityId: proposalId,
    entityName: proposalName
  });
}

export function notifyGoalCreated(userId: string, goalName: string, goalId: string) {
  return createNotificationForEvent({
    type: 'goal_created',
    userId,
    entityId: goalId,
    entityName: goalName
  });
}

export function notifyGoalCompleted(userId: string, goalName: string, goalId: string) {
  return createNotificationForEvent({
    type: 'goal_completed',
    userId,
    entityId: goalId,
    entityName: goalName
  });
}

export function notifyClientCreated(userId: string, clientName: string, clientId: string) {
  return createNotificationForEvent({
    type: 'client_created',
    userId,
    entityId: clientId,
    entityName: clientName
  });
}

export function notifyChatMessage(userId: string, senderName: string, messageId: string) {
  return createNotificationForEvent({
    type: 'chat_message',
    userId,
    entityId: messageId,
    additionalInfo: { senderName }
  });
}

export function notifyCalendarEventCreated(userId: string, eventName: string, eventId: string) {
  return createNotificationForEvent({
    type: 'calendar_event_created',
    userId,
    entityId: eventId,
    entityName: eventName
  });
}
