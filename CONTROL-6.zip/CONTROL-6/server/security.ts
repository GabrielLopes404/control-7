import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { Request, Response, NextFunction, Express } from "express";
import xss from "xss";
import crypto from "crypto";
import { db } from "./db";
import { securityEvents, auditLogs } from "@shared/schema";

const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_TIME = 15 * 60 * 1000; // 15 minutes

export const PASSWORD_REQUIREMENTS = {
  minLength: 8,
  maxLength: 128,
  requireUppercase: true,
  requireLowercase: true,
  requireNumbers: true,
  requireSpecialChars: true,
};

export function validatePasswordStrength(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < PASSWORD_REQUIREMENTS.minLength) {
    errors.push(`Senha deve ter pelo menos ${PASSWORD_REQUIREMENTS.minLength} caracteres`);
  }
  if (password.length > PASSWORD_REQUIREMENTS.maxLength) {
    errors.push(`Senha não pode ter mais que ${PASSWORD_REQUIREMENTS.maxLength} caracteres`);
  }
  if (PASSWORD_REQUIREMENTS.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push("Senha deve conter pelo menos uma letra maiúscula");
  }
  if (PASSWORD_REQUIREMENTS.requireLowercase && !/[a-z]/.test(password)) {
    errors.push("Senha deve conter pelo menos uma letra minúscula");
  }
  if (PASSWORD_REQUIREMENTS.requireNumbers && !/[0-9]/.test(password)) {
    errors.push("Senha deve conter pelo menos um número");
  }
  if (PASSWORD_REQUIREMENTS.requireSpecialChars && !/[!@#$%^&*(),.?":{}|<>_\-+=\[\]\\\/~`]/.test(password)) {
    errors.push("Senha deve conter pelo menos um caractere especial (!@#$%^&*...)");
  }
  
  const commonPasswords = ["password", "123456", "qwerty", "abc123", "password123", "admin123"];
  if (commonPasswords.some(p => password.toLowerCase().includes(p))) {
    errors.push("Senha muito comum, escolha uma mais forte");
  }
  
  return { valid: errors.length === 0, errors };
}

export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function validateCSRFToken(token: string | undefined, sessionToken: string | undefined): boolean {
  if (!token || !sessionToken) return false;
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(sessionToken));
}

export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 login attempts per window
  message: { message: "Muitas tentativas de login. Tente novamente em 15 minutos." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: { message: "Muitas requisições. Tente novamente em alguns segundos." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const strictLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 10,
  message: { message: "Limite de requisições atingido. Aguarde antes de tentar novamente." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const financialLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 20,
  message: { message: "Limite de operações financeiras atingido. Aguarde antes de tentar novamente." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const passwordChangeLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: { message: "Muitas tentativas de alteração de senha. Tente novamente em 1 hora." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const exportLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  message: { message: "Limite de exportações atingido. Aguarde 5 minutos." },
  standardHeaders: true,
  legacyHeaders: false,
});

export function sanitizeInput(input: any): any {
  if (typeof input === "string") {
    return xss(input.trim());
  }
  if (Array.isArray(input)) {
    return input.map(sanitizeInput);
  }
  if (typeof input === "object" && input !== null) {
    const sanitized: Record<string, any> = {};
    for (const [key, value] of Object.entries(input)) {
      sanitized[sanitizeInput(key)] = sanitizeInput(value);
    }
    return sanitized;
  }
  return input;
}

export function sanitizeMiddleware(req: Request, res: Response, next: NextFunction) {
  if (req.body) {
    req.body = sanitizeInput(req.body);
  }
  if (req.query) {
    req.query = sanitizeInput(req.query);
  }
  if (req.params) {
    req.params = sanitizeInput(req.params);
  }
  next();
}

export function getClientIp(req: Request): string {
  return (
    (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
    req.socket.remoteAddress ||
    "unknown"
  );
}

export async function logSecurityEvent(
  type: string,
  req: Request,
  userId?: string,
  details?: any
) {
  try {
    await db.insert(securityEvents).values({
      type,
      userId: userId || null,
      ipAddress: getClientIp(req),
      userAgent: req.headers["user-agent"] || null,
      details: details || null,
    });
  } catch (error) {
    console.error("Failed to log security event:", error);
  }
}

export async function logAuditAction(
  action: string,
  req: Request,
  entityType?: string,
  entityId?: string,
  oldData?: any,
  newData?: any
) {
  try {
    const userId = (req.session as any)?.userId || null;
    await db.insert(auditLogs).values({
      userId,
      action,
      entityType: entityType || null,
      entityId: entityId || null,
      oldData: oldData ? JSON.parse(JSON.stringify(oldData, (key, value) => {
        if (key === "password" || key === "token") return "[REDACTED]";
        return value;
      })) : null,
      newData: newData ? JSON.parse(JSON.stringify(newData, (key, value) => {
        if (key === "password" || key === "token") return "[REDACTED]";
        return value;
      })) : null,
      ipAddress: getClientIp(req),
      userAgent: req.headers["user-agent"] || null,
    });
  } catch (error) {
    console.error("Failed to log audit action:", error);
  }
}

export function setupSecurityMiddleware(app: Express) {
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
          imgSrc: ["'self'", "data:", "https:", "blob:"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          connectSrc: ["'self'", "wss:", "ws:", "https:"],
          frameSrc: ["'none'"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          upgradeInsecureRequests: [],
        },
      },
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: "cross-origin" },
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true,
      },
      noSniff: true,
      xssFilter: true,
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
    })
  );

  app.disable("x-powered-by");

  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader(
      "Permissions-Policy",
      "accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=(), interest-cohort=()"
    );
    res.setHeader("X-Permitted-Cross-Domain-Policies", "none");
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    
    if (process.env.NODE_ENV === "production") {
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
    }
    
    next();
  });

  app.use("/api", apiLimiter);
  app.use("/api/auth/login", loginLimiter);
  app.use("/api/auth/register", loginLimiter);
  app.use("/api/auth/change-password", passwordChangeLimiter);
  app.use("/api/invoices", financialLimiter);
  app.use("/api/expenses", financialLimiter);
  app.use("/api/proposals", financialLimiter);

  app.use(sanitizeMiddleware);
}

export function requireOwnership(entityType: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const userId = (req.session as any)?.userId;
    const entityId = req.params.id;
    
    if (!userId) {
      return res.status(401).json({ message: "Não autorizado" });
    }
    
    if (!entityId) {
      return next();
    }
    
    try {
      const { eq, and } = await import("drizzle-orm");
      const schema = await import("@shared/schema");
      
      let table: any;
      switch (entityType) {
        case "client": table = schema.clients; break;
        case "project": table = schema.projects; break;
        case "task": table = schema.tasks; break;
        case "invoice": table = schema.invoices; break;
        case "expense": table = schema.expenses; break;
        case "proposal": table = schema.proposals; break;
        case "investment": table = schema.investments; break;
        case "goal": table = schema.goals; break;
        case "template": table = schema.templates; break;
        case "calendarEvent": table = schema.calendarEvents; break;
        default: return next();
      }
      
      const [entity] = await db.select({ userId: table.userId }).from(table).where(eq(table.id, entityId));
      
      if (!entity) {
        return res.status(404).json({ message: "Recurso não encontrado" });
      }
      
      if (entity.userId !== userId) {
        await logSecurityEvent("unauthorized_resource_access", req, userId, {
          entityType,
          entityId,
          attemptedAction: req.method,
        });
        return res.status(403).json({ message: "Acesso negado a este recurso" });
      }
      
      next();
    } catch (error) {
      console.error("Ownership check error:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  };
}

export { MAX_LOGIN_ATTEMPTS, LOCK_TIME };
