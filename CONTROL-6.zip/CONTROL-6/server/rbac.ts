import { Request, Response, NextFunction } from "express";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { logSecurityEvent } from "./security";

export type Role = "admin" | "user" | "viewer";

export type Permission =
  | "clients:read"
  | "clients:write"
  | "clients:delete"
  | "projects:read"
  | "projects:write"
  | "projects:delete"
  | "tasks:read"
  | "tasks:write"
  | "tasks:delete"
  | "finance:read"
  | "finance:write"
  | "finance:delete"
  | "proposals:read"
  | "proposals:write"
  | "proposals:delete"
  | "investments:read"
  | "investments:write"
  | "investments:delete"
  | "goals:read"
  | "goals:write"
  | "goals:delete"
  | "calendar:read"
  | "calendar:write"
  | "calendar:delete"
  | "templates:read"
  | "templates:write"
  | "templates:delete"
  | "settings:read"
  | "settings:write"
  | "admin:all";

const rolePermissions: Record<Role, Permission[]> = {
  admin: ["admin:all"],
  user: [
    "clients:read", "clients:write", "clients:delete",
    "projects:read", "projects:write", "projects:delete",
    "tasks:read", "tasks:write", "tasks:delete",
    "finance:read", "finance:write", "finance:delete",
    "proposals:read", "proposals:write", "proposals:delete",
    "investments:read", "investments:write", "investments:delete",
    "goals:read", "goals:write", "goals:delete",
    "calendar:read", "calendar:write", "calendar:delete",
    "templates:read", "templates:write", "templates:delete",
    "settings:read", "settings:write",
  ],
  viewer: [
    "clients:read",
    "projects:read",
    "tasks:read",
    "finance:read",
    "proposals:read",
    "investments:read",
    "goals:read",
    "calendar:read",
    "templates:read",
    "settings:read",
  ],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  const permissions = rolePermissions[role] || [];
  if (permissions.includes("admin:all")) {
    return true;
  }
  return permissions.includes(permission);
}

export function requirePermission(...requiredPermissions: Permission[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const userId = (req.session as any)?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Não autorizado" });
    }

    try {
      const [user] = await db
        .select({ role: users.role, isActive: users.isActive })
        .from(users)
        .where(eq(users.id, userId));

      if (!user || !user.isActive) {
        return res.status(403).json({ message: "Conta desativada" });
      }

      const role = user.role as Role;
      const hasRequiredPermission = requiredPermissions.some((perm) =>
        hasPermission(role, perm)
      );

      if (!hasRequiredPermission) {
        await logSecurityEvent("unauthorized_access", req, userId, {
          requiredPermissions,
          userRole: role,
          path: req.path,
          method: req.method,
        });
        return res.status(403).json({ message: "Permissão negada" });
      }

      next();
    } catch (error) {
      console.error("RBAC check error:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  };
}

export function requireRole(...roles: Role[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const userId = (req.session as any)?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Não autorizado" });
    }

    try {
      const [user] = await db
        .select({ role: users.role, isActive: users.isActive })
        .from(users)
        .where(eq(users.id, userId));

      if (!user || !user.isActive) {
        return res.status(403).json({ message: "Conta desativada" });
      }

      if (!roles.includes(user.role as Role)) {
        await logSecurityEvent("unauthorized_role_access", req, userId, {
          requiredRoles: roles,
          userRole: user.role,
          path: req.path,
          method: req.method,
        });
        return res.status(403).json({ message: "Permissão negada" });
      }

      next();
    } catch (error) {
      console.error("Role check error:", error);
      return res.status(500).json({ message: "Erro interno do servidor" });
    }
  };
}
